package main

import (
    "fmt"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/session"
)

const (
	// oldcoIDP represents the name of the IDP that oldco users authenticate against.
	oldcoIDP = "DemoIDP"
	// newcoIDP represents the name of the IDP that newco users authenticate
	// against.
	newcoIDP = "Azure-AD"
	// newcoUserSuffix is used to distinguish newco users from oldco users.
	newcoUserSuffix = "@strata.io"
)

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	return checkIsAuthenticated(api)
}

func checkIsAuthenticated(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()

	logger.Debug("msg", "determining if user is authenticated")

	oldcoAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", oldcoIDP))
	if oldcoAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated by DemoIDP")
		mapClaim(api, oldcoIDP+".email", "generic.SM_USER")
		mapClaim(api, oldcoIDP+".given_name", "generic.firstname")
		mapClaim(api, oldcoIDP+".family_name", "generic.lastname")

		return true
	}

	newcoAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", newcoIDP))
	if newcoAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated by Azure-AD")
		mapClaim(api, newcoIDP+".email", "generic.SM_USER")
		mapClaim(api, newcoIDP+".givenname", "generic.firstname")
		mapClaim(api, newcoIDP+".surname", "generic.lastname")

		return true
	}
	return false
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, _ := api.Session()
	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
    	logger.Info(fmt.Sprintf("cannot map claim for %s", oldClaim))
		return
	}
	logger.Info(fmt.Sprintf("mapping new claim %s:%s", newClaim, claimValue))
	_ = sess.SetString(newClaim, claimValue)
	sess.Save()
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	logger.Info("msg", "authenticating user")

	hasIDPBeenPicked := req.FormValue("username")
	if !checkIsAuthenticated(api) && len(hasIDPBeenPicked) == 0 {
		logger.Debug("se", "rendering idp picker")
		_, _ = rw.Write([]byte(fmt.Sprintf(idpForm, req.FormValue("SAMLRequest"))))
		return
	}

	if req.Method != http.MethodPost {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"receieved unexpected request type '%s', expected POST",
			req.Method,
		))
		return
	}
	logger.Info("msg", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"failed to parse form from request: %s",
			err,
		))
		return
	}
	var (
		username     = req.Form.Get("username")
		employeeType = "oldco"
		idp          = oldcoIDP
	)
	if strings.HasSuffix(username, newcoUserSuffix) {
		employeeType = "newco"
		idp = newcoIDP
	}
	logger.Info(
		"msg", fmt.Sprintf("received form submission from '%s'", username),
		"employeeType", employeeType,
	)
	logger.Info("msg", fmt.Sprintf("authenticating user against '%s", idp))
	provider, err := api.IdentityProvider(idp)
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf("selected IDP '%s' was not found on AuthProvider", idp))
		return
	}
	provider.Login(rw, req)
}

// idpForm is a basic form that is rendered in order to enable the user to pick which
// IDP they want to authenticate against. The markup can be styled as necessary,
// loaded from an external file, be rendered as a dynamic template, etc.
const idpForm = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Let us log you in</title>
  <link rel="shortcut icon" href = "https://launchpad.stratademo.com/web/image/favicon.png" type="image/x-icon"/>
  <!-- Bootstrap , fonts & icons  -->
  <link rel="stylesheet" type="text/css" href = "https://launchpad.stratademo.com/web/css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href = "https://launchpad.stratademo.com/web/css/style.css"/>
  <link rel="stylesheet" type="text/css" href = "https://launchpad.stratademo.com/web/fonts/typography-font/typo.css"/>
  <link rel="stylesheet" type="text/css" href = "https://launchpad.stratademo.com/web/fonts/fontawesome-5/css/all.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Karla:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Gothic+A1:wght@400;500;700;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Plugin'stylesheets  -->
  <link rel="stylesheet" type="text/css" href="https://launchpad.stratademo.com/web/plugins/aos/aos.min.css">
  <link rel="stylesheet" type="text/css" href="https://launchpad.stratademo.com/web/plugins/fancybox/jquery.fancybox.min.css">
  <link rel="stylesheet" type="text/css" href="https://launchpad.stratademo.com/web/lugins/nice-select/nice-select.min.css">
  <link rel="stylesheet" type="text/css" href="https://launchpad.stratademo.com/web/plugins/slick/slick.min.css">
  <!-- Vendor stylesheets  -->
  <link rel="stylesheet" type="text/css" href="https://launchpad.stratademo.com/web/css/main.css">
  <!-- Custom stylesheet -->
</head>
<body data-theme-mode-panel-active data-theme="light" style="font-family: 'Mazzard H';">
  <div class="site-wrapper overflow-hidden position-relative">
    <!-- Site Header -->
    <!-- Preloader -->
    <!-- <div id="loading">
    <div class="preloader">
     <img src="https://launchpad.stratademo.com/web/image/preloader.gif" alt="preloader">
   </div>
   </div>    -->
    <!--Site Header Area -->
    <header class="site-header site-header--menu-right sign-in-menu-1 site-header--absolute site-header--sticky">
      <div class="container">
        <nav class="navbar site-navbar">
          <!-- Brand Logo-->
          <div class="brand-logo">
            <a href="#">
            </a>
          </div>
          <div class="menu-block-wrapper">
            <div class="menu-overlay"></div>
          </div>
          <div class="header-btn sign-in-header-btn-1 ms-auto d-none d-xs-inline-flex">
          </div>
          <div class="header-btns  ">
            <a class="" href="#">
            </a>
            <a class="" href="#">
            </a>
          </div>
          <!-- mobile menu trigger -->
          <div class="mobile-menu-trigger">
            <span></span>
          </div>
          <!--/.Mobile Menu Hamburger Ends-->
        </nav>
      </div>
    </header>
    <!-- navbar- -->
    <!-- Sign In Area -->
    <div class="reset-password-1">
      <div class="container">
        <div class="row justify-content-lg-end justify-content-center">
          <div class="col-xl-5 col-lg-6 col-md-8">
            <div class="reset-password-1-box  justify-content-lg-end">
              <div class="heading text-center">
                <h2>Provide username</h2>
                <p>This lets us know where to send you for authentication</p>
              </div>
              <form method="post">
				<input type="hidden" name="SAMLRequest" id="SAMLRequest" value="%s">
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" name="username" id="username" class="form-control" placeholder="ex: jdoe@newco.com">
                </div>
                  <center><input type="submit">
                <div class="create-new-acc-text text-center">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--Footer Area-->
    <footer class="footer-sign-in-1">
      <div class="container">
        <div class="row">
          <div class="col-lg-5 col-sm-9">
            <div class="row">
              <div class="col-xl-9 col-lg-10 col-md-8">
                <a href="#"><img src="https://launchpad.stratademo.com/web/image/logos/logo-paste.png" alt="" class="footer-logo"></a>
                <div class="content">
                </div>
                <div class="social-icons">
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-7 col-md-12">
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">
                <div class="footer-widget">
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</body>
</html>
`